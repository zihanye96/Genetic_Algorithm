# GA

Genetic Algorithm for Variable Selection in Regression (STAT243 Fall 2019)

- Ye, Zihan
- Xu, Jing
- Berkalieva, Asem
